<?php namespace agricolacentral\Commands;

abstract class Command {

	//

}
