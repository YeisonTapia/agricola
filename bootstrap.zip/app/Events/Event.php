<?php namespace agricolacentral\Events;

abstract class Event {

	//

}
