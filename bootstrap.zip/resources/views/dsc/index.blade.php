@extends('admin.principal')

@section('content')
	<div class="right_col" role="main">
       	<div class="container">
			<div class="row">
			

			
<h1 class="text-center">DECLARACION  SOPORTE DE CUENTA </h1>
<form action="#" method="post">
 <p >Contrato No:<input type="text" name="contrato" /></p>
 <p>ACTIVIDAD: <input type="text" name="actividad" /></p>
 <p>VALOR CONTRATO:<input type="text" name="valor" /></p>
 <p>APORTES A LA SEGURIDAD SOCIAL: <select name="SEGURIDADSOCIAL">
<option selected value="0"> Elige una opción </option>
<option>SI</option>
<option>NO</option>
</select></p>
 <p>APORTES VOLUNTAROS DE PENSION:<select name="PENSION">
<option selected value="0" > Elige una opción </option>
<option>SI</option>
<option>NO</option>
</select></p>
 <p>APORTES AFC:<select name="AFC">
<option selected value="0"> Elige una opción </option>
<option>SI</option>
<option>NO</option>
</select></p>
 <p>ESTOY OBLIGADO A PRESENTAR DECLARACION DE RENTA:<select name="RENTA">
<option selected value="0"> Elige una opción </option>
<option>SI</option>
<option>NO</option>
</select></p>
 <p>MIS  INGRESOS  CORRESPONDE EN UN PORCENTAJE IGUAL O SUPERIOR AL 80% DE LA REALIZACION DE UNA ACTIVIDADES ECONOMICA:<select name="ACTIVIDADECONOMICA">
<option selected value="0"> Elige una opción </option>
<option>SI</option>
<option>NO</option>
</select></p>
 <p>MIS  INGRESOS  ANUALES  SUPERAN  LAS 4.073 UVT ($109.323.393)<select name="INGRESOSANUALES">
<option selected value="0"> Elige una opción </option>
<option>SI</option>
<option>NO</option>
</select></p>
<button type="submit" class="col-md-5 btn btn-success center">Guardar</button>
</form>



			</div>
			</div>
			</div>
@endsection